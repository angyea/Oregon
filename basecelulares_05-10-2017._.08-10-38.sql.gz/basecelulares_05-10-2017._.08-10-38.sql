-- Dump de la Base de Datos
-- Fecha: jueves 05 octubre 2017 - 08:05:38
--
-- Version: 1.1.1, del 05-10-2017 , insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `basecelulares`
-- ------------------------------------------------------
-- Server version	10.1.25-MariaDB

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS administrador;
CREATE TABLE `administrador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) DEFAULT NULL,
  `correo` varchar(50) NOT NULL,
  `nive_usua` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `administrador`
--

LOCK TABLES administrador WRITE;
INSERT INTO administrador VALUES(, , , , , , );
INSERT INTO administrador VALUES(, , , , , , );
INSERT INTO administrador VALUES(, , , , , , );
INSERT INTO administrador VALUES(, , , , , , );
INSERT INTO administrador VALUES(, , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `carro`
--

DROP TABLE IF EXISTS carro;
CREATE TABLE `carro` (
  `id_carro` int(11) NOT NULL AUTO_INCREMENT,
  `placa` varchar(10) NOT NULL,
  `marca` varchar(12) NOT NULL,
  `color` varchar(12) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  PRIMARY KEY (`id_carro`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carro`
--

LOCK TABLES carro WRITE;
INSERT INTO carro VALUES(, , , , );
UNLOCK TABLES;


--
-- Table structure for table `chofer`
--

DROP TABLE IF EXISTS chofer;
CREATE TABLE `chofer` (
  `id_chofer` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `dni` int(8) NOT NULL,
  `categoria` varchar(5) NOT NULL,
  `numero` int(10) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  PRIMARY KEY (`id_chofer`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chofer`
--

LOCK TABLES chofer WRITE;
INSERT INTO chofer VALUES(, , , , , , , );
INSERT INTO chofer VALUES(, , , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `encomienda`
--

DROP TABLE IF EXISTS encomienda;
CREATE TABLE `encomienda` (
  `id_encomienda` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(15) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `fecha_salida` varchar(30) NOT NULL,
  `fecha_llegada` varchar(30) NOT NULL,
  `precio` double NOT NULL,
  `origen` varchar(25) NOT NULL,
  `destino` varchar(25) NOT NULL,
  `destinatario` varchar(100) NOT NULL,
  PRIMARY KEY (`id_encomienda`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `encomienda`
--

LOCK TABLES encomienda WRITE;
INSERT INTO encomienda VALUES(, , , , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `factura`
--

DROP TABLE IF EXISTS factura;
CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL AUTO_INCREMENT,
  `numero` int(11) NOT NULL,
  `fechai` varchar(12) NOT NULL,
  `cliente` varchar(15) NOT NULL,
  `encomienda` varchar(15) NOT NULL,
  `precio` varchar(10) NOT NULL,
  `cantidad` varchar(10) NOT NULL,
  PRIMARY KEY (`id_factura`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura`
--

LOCK TABLES factura WRITE;
INSERT INTO factura VALUES(, , , , , , );
INSERT INTO factura VALUES(, , , , , , );
INSERT INTO factura VALUES(, , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `oficina`
--

DROP TABLE IF EXISTS oficina;
CREATE TABLE `oficina` (
  `id_oficina` int(11) NOT NULL AUTO_INCREMENT,
  `numero` varchar(25) NOT NULL,
  `razon` varchar(50) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `telefono` varchar(9) NOT NULL,
  PRIMARY KEY (`id_oficina`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `oficina`
--

LOCK TABLES oficina WRITE;
INSERT INTO oficina VALUES(, , , , );
INSERT INTO oficina VALUES(, , , , );
INSERT INTO oficina VALUES(, , , , );
INSERT INTO oficina VALUES(, , , , );
INSERT INTO oficina VALUES(, , , , );
UNLOCK TABLES;


--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS usuarios;
CREATE TABLE `usuarios` (
  `id_usuarios` int(11) NOT NULL AUTO_INCREMENT,
  `dni` int(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `fechai` varchar(40) NOT NULL,
  `direccion` varchar(300) NOT NULL,
  `telefono` int(20) NOT NULL,
  PRIMARY KEY (`id_usuarios`),
  UNIQUE KEY `cedula` (`dni`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES usuarios WRITE;
INSERT INTO usuarios VALUES(, , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , );
UNLOCK TABLES;



-- Dump de la Base de Datos Completo.